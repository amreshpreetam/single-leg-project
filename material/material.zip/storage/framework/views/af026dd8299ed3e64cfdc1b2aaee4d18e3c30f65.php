<div class="sidebar" data-color="orange" data-background-color="white" data-image="<?php echo e(asset('material')); ?>/img/sidebar-1.jpg">
  <!--
      Tip 1: You can change the color of the sidebar using: data-color="purple | azure | green | orange | danger"

      Tip 2: you can also add an image using data-image tag
  -->
  <div class="logo">
    <a href="https://bestgloballife.com/" class="simple-text logo-normal">
      <i><img style="width:25px" src="<?php echo e(asset('material')); ?>/img/apple-icon.png"></i>
      <?php echo e(__('Best Dashboard')); ?>

    </a>
  </div>
  <div class="sidebar-wrapper">
    <ul class="nav">
      <li class="nav-item<?php echo e($activePage == 'dashboard' ? ' active' : ''); ?>">
        <a class="nav-link" href="<?php echo e(route('home')); ?>">
          <i class="material-icons">dashboard</i>
            <p><?php echo e(__('Dashboard')); ?></p>
        </a>
      </li>
      <li class="nav-item <?php echo e(($activePage == 'profile' || $activePage == 'user-management') ? ' active' : ''); ?>">
        <a class="nav-link" data-toggle="collapse" href="#myprofile" aria-expanded="true">
          <i><img style="width:25px" src="<?php echo e(asset('material')); ?>/img/laravel.svg"></i>
          <p><?php echo e(__('My Profile')); ?>

            <b class="caret"></b>
          </p>
        </a>
        <div class="collapse show" id="myprofile">
          <ul class="nav">
            <li class="nav-item<?php echo e($activePage == 'profile' ? ' active' : ''); ?>">
              <a class="nav-link" href="<?php echo e(route('profile.edit')); ?>">
                <span class="sidebar-mini"> UP </span>
                <span class="sidebar-normal"><?php echo e(__('User profile')); ?> </span>
              </a>
            </li>
            <li class="nav-item<?php echo e($activePage == 'user-management' ? ' active' : ''); ?>">
              <a class="nav-link" href="<?php echo e(route('user.index')); ?>">
                <span class="sidebar-mini"> UM </span>
                <span class="sidebar-normal"> <?php echo e(__('User Management')); ?> </span>
              </a>
            </li>
          </ul>
        </div>
      </li>
      
      <li class="nav-item <?php echo e(($activePage == 'profile' || $activePage == 'user-management') ? ' active' : ''); ?>">
        <a class="nav-link" data-toggle="collapse" href="#mynetwork" aria-expanded="true">
          <i><img style="width:25px" src="<?php echo e(asset('material')); ?>/img/laravel.svg"></i>
          <p><?php echo e(__('My Network')); ?>

            <b class="caret"></b>
          </p>
        </a>
        <div class="collapse show" id="mynetwork">
          <ul class="nav">
            <li class="nav-item<?php echo e($activePage == 'profile' ? ' active' : ''); ?>">
              <a class="nav-link" href="<?php echo e(route('profile.edit')); ?>">
                <span class="sidebar-mini"> MD </span>
                <span class="sidebar-normal"><?php echo e(__('My Downline')); ?> </span>
              </a>
            </li>
            <li class="nav-item<?php echo e($activePage == 'user-management' ? ' active' : ''); ?>">
              <a class="nav-link" href="<?php echo e(route('user.index')); ?>">
                <span class="sidebar-mini"> GT </span>
                <span class="sidebar-normal"> <?php echo e(__('Global Team')); ?> </span>
              </a>
            </li>
          </ul>
        </div>
      </li>
      
      <li class="nav-item <?php echo e(($activePage == 'profile' || $activePage == 'user-management') ? ' active' : ''); ?>">
        <a class="nav-link" data-toggle="collapse" href="#myEpin" aria-expanded="true">
          <i><img style="width:25px" src="<?php echo e(asset('material')); ?>/img/laravel.svg"></i>
          <p><?php echo e(__('My E-Pin')); ?>

            <b class="caret"></b>
          </p>
        </a>
        <div class="collapse show" id="myEpin">
          <ul class="nav">
            <li class="nav-item<?php echo e($activePage == 'profile' ? ' active' : ''); ?>">
              <a class="nav-link" href="<?php echo e(route('profile.edit')); ?>">
                <span class="sidebar-mini"> PR </span>
                <span class="sidebar-normal"><?php echo e(__('My Pin Request')); ?> </span>
              </a>
            </li>
            <li class="nav-item<?php echo e($activePage == 'user-management' ? ' active' : ''); ?>">
              <a class="nav-link" href="<?php echo e(route('user.index')); ?>">
                <span class="sidebar-mini"> MP </span>
                <span class="sidebar-normal"> <?php echo e(__('My Pin')); ?> </span>
              </a>
            </li>
          </ul>
        </div>
      </li>
      
       <li class="nav-item <?php echo e(($activePage == 'profile' || $activePage == 'user-management'||$activePage == 'profile' || $activePage == 'user-management' || $activePage == 'profile' || $activePage == 'user-management') ? ' active' : ''); ?>">
        <a class="nav-link" data-toggle="collapse" href="#myIncome" aria-expanded="true">
          <i><img style="width:25px" src="<?php echo e(asset('material')); ?>/img/laravel.svg"></i>
          <p><?php echo e(__('My Income')); ?>

            <b class="caret"></b>
          </p>
        </a>
        <div class="collapse show" id="myIncome">
          <ul class="nav">
            <li class="nav-item<?php echo e($activePage == 'profile' ? ' active' : ''); ?>">
              <a class="nav-link" href="<?php echo e(route('profile.edit')); ?>">
                <span class="sidebar-mini"> DI </span>
                <span class="sidebar-normal"><?php echo e(__('Direct Inome')); ?> </span>
              </a>
            </li>
            <li class="nav-item<?php echo e($activePage == 'user-management' ? ' active' : ''); ?>">
              <a class="nav-link" href="<?php echo e(route('user.index')); ?>">
                <span class="sidebar-mini"> LI </span>
                <span class="sidebar-normal"> <?php echo e(__('Level Income')); ?> </span>
              </a>
            </li>
             <li class="nav-item<?php echo e($activePage == 'profile' ? ' active' : ''); ?>">
              <a class="nav-link" href="<?php echo e(route('profile.edit')); ?>">
                <span class="sidebar-mini"> GI </span>
                <span class="sidebar-normal"><?php echo e(__('Global Income')); ?> </span>
              </a>
            </li>
            <li class="nav-item<?php echo e($activePage == 'user-management' ? ' active' : ''); ?>">
              <a class="nav-link" href="<?php echo e(route('user.index')); ?>">
                <span class="sidebar-mini"> RI </span>
                <span class="sidebar-normal"> <?php echo e(__('Royality Income')); ?> </span>
              </a>
            </li>
             <li class="nav-item<?php echo e($activePage == 'profile' ? ' active' : ''); ?>">
              <a class="nav-link" href="<?php echo e(route('profile.edit')); ?>">
                <span class="sidebar-mini"> LB </span>
                <span class="sidebar-normal"><?php echo e(__('Leadership Benifite')); ?> </span>
              </a>
            </li>
            <li class="nav-item<?php echo e($activePage == 'user-management' ? ' active' : ''); ?>">
              <a class="nav-link" href="<?php echo e(route('user.index')); ?>">
                <span class="sidebar-mini"> RS </span>
                <span class="sidebar-normal"> <?php echo e(__('Rewards')); ?> </span>
              </a>
            </li>
          </ul>
        </div>
      </li>
     <!-- <li class="nav-item<?php echo e($activePage == 'table' ? ' active' : ''); ?>">
        <a class="nav-link" href="<?php echo e(route('table')); ?>">
          <i class="material-icons">content_paste</i>
            <p><?php echo e(__('Table List')); ?></p>
        </a>
      </li>
      <li class="nav-item<?php echo e($activePage == 'notifications' ? ' active' : ''); ?>">
        <a class="nav-link" href="<?php echo e(route('notifications')); ?>">
          <i class="material-icons">notifications</i>
          <p><?php echo e(__('Notifications')); ?></p>
        </a>
      </li>
      
      
       -->
    </ul>
  </div>
</div>
<?php /**PATH E:\material\resources\views/layouts/navbars/sidebar.blade.php ENDPATH**/ ?>