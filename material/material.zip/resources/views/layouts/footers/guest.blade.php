<footer class="footer">
    <div class="container">
        <nav class="float-left">
        <ul>
            <li>
            <a href="http://www.bestgloballife.com">
                {{ __('Best Global Life') }}
            </a>
            </li>
            <li>
            <a href="http://www.bestgloballife.com/about/">
                {{ __('About Us') }}
            </a>
            </li>
            <li>
            <a href="http://www.bestgloballife.com/services/">
                {{ __('Business Plan') }}
            </a>
            </li>
            <li>
            <a href="http://www.bestgloballife.com/contact-us/">
                {{ __('Contact Us') }}
            </a>
            </li>
        </ul>
        </nav>
        <div class="copyright float-right">
        &copy;
        <script>
            document.write(new Date().getFullYear())
        </script>, made with <i class="material-icons">favorite</i> by
        <a href="https://www.speedsolutions.co.in" target="_blank">Speed Solutions, India</a>
        </div>
    </div>
</footer>